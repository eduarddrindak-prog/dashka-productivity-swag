import { useState, type CSSProperties, type ReactNode } from "react";
import {
  ArrowUpRight,
  CheckCircle2,
  Heart,
  Settings,
  Sparkles,
  Star,
} from "lucide-react";

import "./styles/demo.css";

import {
  Accordion,
  Alert,
  Avatar,
  Badge,
  Button,
  ButtonGroup,
  Card,
  CardHeader,
  Checkbox,
  Dialog,
  Divider,
  Drawer,
  DropdownMenu,
  Field,
  Footer,
  Header,
  Icon,
  IconButton,
  Image,
  Input,
  Link,
  Motion,
  MotionGroup,
  Pill,
  Popover,
  Price,
  Progress,
  Radio,
  Search,
  Select,
  Skeleton,
  Spinner,
  Tabs,
  Text,
  Textarea,
  Toast,
  ToastProvider,
  Tooltip,
  Toggle,
  useToast,
} from "./components/ui";

const colors = [
  ["Page", "var(--color-page)", "--color-page"],
  ["Surface", "var(--color-surface)", "--color-surface"],
  ["Text", "var(--color-text)", "--color-text"],
  ["Text soft", "var(--color-text-soft)", "--color-text-soft"],
  ["Accent", "var(--color-accent)", "--color-accent"],
  ["Accent soft", "var(--color-accent-soft)", "--color-accent-soft"],
  ["Border", "var(--color-border)", "--color-border"],
  ["Success", "var(--color-success)", "--color-success"],
];

const typeScale = [
  ["Display", "var(--text-3xl)", "Build the next local brand online."],
  ["Heading", "var(--text-2xl)", "A clean landing page system."],
  ["Large", "var(--text-lg)", "Readable supporting copy for hero sections."],
  ["Base", "var(--text-base)", "Standard paragraph text used across sections."],
  ["Small", "var(--text-sm)", "Compact descriptions inside cards and forms."],
  ["Extra small", "var(--text-xs)", "Labels, metadata, badges, and tiny UI text."],
];

const headerItems = [
  { label: "Home", href: "/", current: true },
  { label: "Services", href: "/services" },
  { label: "Work", href: "/work" },
  { label: "About", href: "/about" },
];

const footerColumns = [
  {
    title: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Team", href: "/team" },
      { label: "Careers", href: "/careers" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Blog", href: "/blog" },
      { label: "Docs", href: "/docs" },
      { label: "Support", href: "/support" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy", href: "/privacy" },
      { label: "Terms", href: "/terms" },
      { label: "Cookies", href: "/cookies" },
    ],
  },
];

const cards = [
  {
    eyebrow: "01",
    title: "Strategy first",
    description:
      "Plan the offer, audience, and page structure before styling.",
  },
  {
    eyebrow: "02",
    title: "Token driven",
    description:
      "Change colors, spacing, radius, shadows, and typography from the system.",
  },
  {
    eyebrow: "03",
    title: "Component ready",
    description:
      "Compose future sites from reusable primitives instead of rebuilding UI.",
  },
];

function ShowcaseSection({
  eyebrow,
  title,
  description,
  children,
  id,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  children: ReactNode;
  id?: string;
}) {
  return (
    <section className="section section--compact" id={id}>
      <div className="container stack">
        <div>
          <p className="eyebrow">{eyebrow}</p>
          <h2 className="heading">{title}</h2>
          {description && <p className="subheading">{description}</p>}
        </div>
        {children}
      </div>
    </section>
  );
}

function InteractionDemos() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { addToast } = useToast();

  return (
    <>
      <ShowcaseSection
        eyebrow="Overlays"
        title="Dialog, Popover, Dropdown and Drawer"
        description="The harder interaction primitives are kept generic so they can be reused inside any future site."
      >
        <div className="demo-section">
          <div className="demo-flex">
            <Button onClick={() => setDialogOpen(true)}>Open dialog</Button>

            <Popover
              open={popoverOpen}
              onOpenChange={setPopoverOpen}
              trigger={<Button variant="secondary">Open popover</Button>}
              placement="bottom"
              align="center"
            >
              <div className="stack" style={{ minWidth: "14rem" }}>
                <Button variant="ghost" size="sm">Preview</Button>
                <Button variant="ghost" size="sm">Duplicate</Button>
                <Button variant="ghost" size="sm">Share</Button>
              </div>
            </Popover>

            <DropdownMenu
              trigger={<Button variant="secondary">Actions</Button>}
              items={[
                { id: "edit", label: "Edit", onSelect: () => undefined },
                { id: "duplicate", label: "Duplicate", onSelect: () => undefined },
                {
                  id: "share",
                  label: "Share",
                  onSelect: () => undefined,
                  separatorBefore: true,
                },
                {
                  id: "delete",
                  label: "Delete",
                  destructive: true,
                  onSelect: () => undefined,
                },
              ]}
            />

            <Button variant="secondary" onClick={() => setDrawerOpen(true)}>
              Open drawer
            </Button>

            <Button
              variant="ghost"
              onClick={() =>
                addToast({
                  title: "Toast example",
                  message: "This notification uses the shared toast system.",
                  variant: "success",
                })
              }
            >
              Show toast
            </Button>
          </div>
        </div>
      </ShowcaseSection>

      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        title="Generic dialog"
        description="Arbitrary content can be composed inside the reusable dialog primitive."
        size="md"
      >
        <div className="stack">
          <Field label="Name" hint="Example field inside a dialog">
            <Input placeholder="Jane Doe" />
          </Field>
          <Field label="Notes">
            <Textarea placeholder="Type something useful..." rows={4} />
          </Field>
          <div className="demo-flex">
            <Button onClick={() => setDialogOpen(false)}>Confirm</Button>
            <Button variant="secondary" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
          </div>
        </div>
      </Dialog>

      <Drawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title="Drawer"
        description="A reusable side panel for mobile navigation, filters, details, or contextual content."
      >
        <div className="stack">
          <p>
            Drawer content is completely controlled by the page using it.
          </p>
          <Button onClick={() => setDrawerOpen(false)}>Close drawer</Button>
        </div>
      </Drawer>
    </>
  );
}

function FormDemos() {
  const [searchValue, setSearchValue] = useState("");
  const [selectValue, setSelectValue] = useState("");

  return (
    <ShowcaseSection
      eyebrow="Forms"
      title="Inputs and interactive controls"
      description="Native-first form primitives plus the custom Select and Search controls."
    >
      <div className="grid grid--3">
        <Card>
          <CardHeader eyebrow="Text" title="Input & textarea" />
          <div className="stack" style={{ marginTop: "var(--space-6)" }}>
            <Field label="Name" hint="Standard text input">
              <Input placeholder="Jane Doe" />
            </Field>
            <Field label="Description" hint="Multiline content">
              <Textarea placeholder="Write something..." rows={4} />
            </Field>
          </div>
        </Card>

        <Card>
          <CardHeader eyebrow="Choice" title="Select & search" />
          <div className="stack" style={{ marginTop: "var(--space-6)" }}>
            <Field label="Select" hint="Custom dropdown primitive">
              <Select
                value={selectValue}
                onValueChange={setSelectValue}
                placeholder="Choose..."
                options={[
                  { value: "one", label: "Option One" },
                  { value: "two", label: "Option Two" },
                  { value: "three", label: "Option Three" },
                  { value: "disabled", label: "Disabled option", disabled: true },
                ]}
              />
            </Field>

            <Field label="Search" hint="Search input with clear state">
              <Search
                value={searchValue}
                onChange={(event) => setSearchValue(event.target.value)}
                onClear={() => setSearchValue("")}
                placeholder="Search components..."
              />
            </Field>
          </div>
        </Card>

        <Card>
          <CardHeader eyebrow="Controls" title="Checkbox, radio & toggle" />
          <div className="stack" style={{ marginTop: "var(--space-6)" }}>
            <Checkbox label="Accept terms" />
            <Checkbox label="Checked by default" defaultChecked />
            <Radio label="Option A" name="demo-radio" defaultChecked />
            <Radio label="Option B" name="demo-radio" />
            <Toggle label="Enable notifications" defaultChecked />
          </div>
        </Card>
      </div>
    </ShowcaseSection>
  );
}

function FeedbackDemos() {
  return (
    <ShowcaseSection
      eyebrow="Feedback"
      title="Status, loading and progress primitives"
      description="Small components that communicate state without imposing a visual style on the final website."
    >
      <div className="grid grid--3">
        <Card>
          <CardHeader eyebrow="Alert" title="Semantic messages" />
          <div className="stack" style={{ marginTop: "var(--space-6)" }}>
            <Alert variant="info" title="Information">
              Helpful contextual information.
            </Alert>
            <Alert variant="success" title="Success">
              The action completed successfully.
            </Alert>
            <Alert variant="warning" title="Warning">
              Something deserves attention.
            </Alert>
            <Alert variant="danger" title="Danger">
              Something needs to be corrected.
            </Alert>
          </div>
        </Card>

        <Card>
          <CardHeader eyebrow="Loading" title="Spinner & skeleton" />
          <div className="demo-flex" style={{ alignItems: "center", marginTop: "var(--space-6)" }}>
            <Spinner size="sm" label="Loading" />
            <Spinner size="md" label="Loading" />
            <Spinner size="lg" label="Loading" />
          </div>
          <div className="stack" style={{ marginTop: "var(--space-6)" }}>
            <Skeleton variant="text" width="12rem" />
            <Skeleton variant="block" width="100%" height="4rem" />
            <Skeleton variant="circle" width="2.5rem" height="2.5rem" />
          </div>
        </Card>

        <Card>
          <CardHeader eyebrow="Progress" title="Progress states" />
          <div className="stack" style={{ marginTop: "var(--space-6)" }}>
            <Progress value={28} label="Loading" />
            <Progress value={72} label="Uploading" />
            <Progress value={100} label="Complete" />
          </div>
        </Card>
      </div>
    </ShowcaseSection>
  );
}

export default function App() {
  const [motionDemoKey, setMotionDemoKey] = useState(0);

  return (
    <main className="app-shell">
      <Header
        logo={<span className="header__logo">Concept Studio</span>}
        items={headerItems}
        primaryAction={{ label: "Book a call", href: "/contact" }}
        secondaryAction={{
          label: "Log in",
          href: "/login",
          variant: "secondary",
        }}
        sticky
      />

      <ToastProvider>
        <div className="container">
          <header className="showcase-header">
            <div>
              <p className="eyebrow">Starter Kit</p>
              <h1 className="heading">Concept Landing System</h1>
              <p className="subheading">
                A component-first starter for building custom websites from
                scratch. Change the design system, then compose each page
                uniquely.
              </p>
            </div>

            <Button
              variant="secondary"
              size="sm"
              href="#components"
              iconRight={<ArrowUpRight size={15} />}
            >
              View components
            </Button>
          </header>

          <section className="hero-panel">
            <div>
              <Badge>Token based</Badge>
              <h2 className="display">Build concept websites faster.</h2>
              <p className="subheading">
                No themes. No prebuilt page templates. Just reusable
                components, design tokens, and motion primitives.
              </p>

              <div className="hero-actions">
                <Button size="lg" withArrow>Start project</Button>
                <Button variant="secondary" size="lg">Explore tokens</Button>
              </div>
            </div>
          </section>
        </div>

        <ShowcaseSection
          eyebrow="Design system"
          title="Core visual tokens"
          description="The showcase reads directly from CSS variables so the same system can be retuned for every future project."
          id="tokens"
        >
          <div className="grid grid--3">
            {colors.map(([label, value, token]) => (
              <article
                className="token-swatch"
                key={token}
                style={{ "--swatch": value } as CSSProperties}
              >
                <div className="token-swatch__color" />
                <div className="token-swatch__body">
                  <p className="token-name">{label}</p>
                  <p className="token-value">{token}</p>
                </div>
              </article>
            ))}
          </div>
        </ShowcaseSection>

        <ShowcaseSection
          eyebrow="Typography"
          title="Type scale"
          description="The same typography tokens used by the component layer."
        >
          <div className="stack">
            {typeScale.map(([label, size, sample]) => (
              <div className="type-sample" key={label}>
                <p className="token-value">{label} / {size}</p>
                <p style={{ margin: 0, fontSize: size, lineHeight: "var(--line-snug)" }}>
                  {sample}
                </p>
              </div>
            ))}
          </div>
        </ShowcaseSection>

        <ShowcaseSection
          eyebrow="Core UI"
          title="Everyday building blocks"
          description="The small primitives that should be available on practically every project."
          id="components"
        >
          <div className="grid grid--3">
            <Card>
              <CardHeader eyebrow="Buttons" title="Actions" />
              <div className="stack" style={{ marginTop: "var(--space-6)" }}>
                <ButtonGroup>
                  <Button size="sm">Small</Button>
                  <Button size="md">Medium</Button>
                  <Button size="lg">Large</Button>
                </ButtonGroup>
                <ButtonGroup>
                  <Button variant="secondary">Secondary</Button>
                  <Button variant="ghost">Ghost</Button>
                  <Button variant="danger">Danger</Button>
                </ButtonGroup>
                <div className="demo-flex">
                  <IconButton
                    variant="primary"
                    size="md"
                    icon={<Settings size={16} />}
                    label="Settings"
                  />
                  <IconButton
                    variant="secondary"
                    size="md"
                    icon={<Heart size={16} />}
                    label="Favorite"
                  />
                  <IconButton
                    variant="ghost"
                    size="sm"
                    icon={<Star size={14} />}
                    label="Star"
                  />
                </div>
              </div>
            </Card>

            <Card>
              <CardHeader eyebrow="Text" title="Text, links & dividers" />
              <div className="stack" style={{ marginTop: "var(--space-6)" }}>
                <Text variant="display">Display text</Text>
                <Text variant="heading">Heading text</Text>
                <Text variant="subtitle">Subtitle text</Text>
                <Text variant="body">Body text</Text>
                <Text variant="small">Small text</Text>
                <Text variant="caption">Caption text</Text>
                <Divider />
                <Link variant="accent" withArrow>Learn more</Link>
                <Link variant="muted">Muted link</Link>
              </div>
            </Card>

            <Card>
              <CardHeader eyebrow="Tags" title="Badge & pill" />
              <div className="stack" style={{ marginTop: "var(--space-6)" }}>
                <div className="demo-flex">
                  <Badge variant="filled" tone="accent">Accent</Badge>
                  <Badge variant="filled" tone="success">Success</Badge>
                  <Badge variant="outlined" tone="danger">Danger</Badge>
                </div>
                <div className="demo-flex">
                  <Pill variant="filled">Design</Pill>
                  <Pill variant="outlined">Development</Pill>
                  <Pill variant="subtle">React</Pill>
                </div>
              </div>
            </Card>

            <Card>
              <CardHeader eyebrow="Media" title="Image & avatar" />
              <div className="stack" style={{ marginTop: "var(--space-6)" }}>
                <Image
                  src="https://images.unsplash.com/photo-1497366811353-6870744d04b2"
                  alt="Modern workspace"
                  aspectRatio="16 / 10"
                  fit="cover"
                  radius="lg"
                />
                <div className="demo-flex">
                  <Avatar size="sm" alt="John" initials="JD" />
                  <Avatar size="md" alt="Jane" initials="JS" />
                  <Avatar size="lg" alt="Bob" initials="BC" />
                  <Avatar size="md" alt="Circle" initials="O" variant="circle" />
                  <Avatar size="md" alt="Square" initials="S" variant="square" />
                </div>
              </div>
            </Card>

            <Card>
              <CardHeader eyebrow="Data" title="Price & icon" />
              <div className="stack" style={{ marginTop: "var(--space-6)" }}>
                <Price size="sm" amount={29} period="month" />
                <Price size="md" amount={99} period="month" />
                <Price size="lg" amount={299} period="month" />
                <div className="demo-flex" style={{ alignItems: "center" }}>
                  <Icon icon={Sparkles} size="xs" />
                  <Icon icon={Sparkles} size="sm" color="muted" />
                  <Icon icon={Sparkles} size="md" color="accent" />
                  <Icon icon={CheckCircle2} size="lg" color="success" />
                  <Icon icon={Sparkles} size="xl" color="danger" />
                </div>
              </div>
            </Card>

            <Card>
              <CardHeader eyebrow="Content" title="Accordion" />
              <Accordion
                items={[
                  {
                    id: "core-1",
                    title: "Reusable content",
                    content: <p>Any React content can be placed inside.</p>,
                  },
                  {
                    id: "core-2",
                    title: "Multiple modes",
                    content: <p>Single and multiple open states are supported.</p>,
                  },
                ]}
              />
            </Card>
          </div>
        </ShowcaseSection>

        <FormDemos />
        <FeedbackDemos />
        <InteractionDemos />

        <ShowcaseSection
          eyebrow="Navigation"
          title="Tabs and contextual help"
          description="Interaction primitives that often appear in product pages, dashboards, and complex landing experiences."
        >
          <div className="grid grid--2">
            <Card>
              <Tabs
                items={[
                  {
                    id: "overview",
                    label: "Overview",
                    content: (
                      <div className="stack">
                        <p>Flexible content inside a reusable tab panel.</p>
                        <Button size="sm">View</Button>
                      </div>
                    ),
                  },
                  {
                    id: "details",
                    label: "Details",
                    content: (
                      <Alert variant="info" title="System note">
                        Tabs are generic and not tied to a specific page pattern.
                      </Alert>
                    ),
                  },
                  {
                    id: "status",
                    label: "Status",
                    content: <Progress value={72} label="Progress" />,
                  },
                ]}
              />
            </Card>

            <Card>
              <CardHeader eyebrow="Tooltip" title="Micro guidance" />
              <div className="demo-flex" style={{ alignItems: "center", marginTop: "var(--space-6)" }}>
                <Tooltip content="Helpful information for the current action" side="top">
                  <Button variant="secondary">Hover me</Button>
                </Tooltip>
                <Tooltip content="Settings">
                  <IconButton
                    variant="ghost"
                    size="md"
                    icon={<Settings size={16} />}
                    label="Settings"
                  />
                </Tooltip>
              </div>
            </Card>
          </div>
        </ShowcaseSection>

        <ShowcaseSection
  eyebrow="Motion"
  title="Reusable motion primitives"
  description="Motion is kept separate from components, so any element can be animated with a local className override."
>
  <div className="stack">
    <div className="demo-flex">
      <Button onClick={() => setMotionDemoKey((key) => key + 1)}>
        Play all presets
      </Button>

      <span className="token-value">
        Click to replay
      </span>
    </div>

    <div className="motion-demo-grid" key={motionDemoKey}>
      {[
        "fade",
        "fade-up",
        "fade-down",
        "fade-left",
        "fade-right",
        "scale",
        "lift",
        "slide",
        "expand",
        "collapse",
      ].map((preset) => (
        <Motion
          key={preset}
          preset={preset as
            | "fade"
            | "fade-up"
            | "fade-down"
            | "fade-left"
            | "fade-right"
            | "scale"
            | "lift"
            | "slide"
            | "expand"
            | "collapse"}
            duration={2000}
          className="motion-demo-card"
        >
          <span className="motion-demo-label">{preset}</span>
          <strong>Motion preset</strong>
        </Motion>
      ))}
    </div>

    <div className="motion-demo-stagger">
      <p className="eyebrow">Stagger</p>

      <MotionGroup stagger={140}>
        {["fade", "slide", "expand", "collapse"].map((preset) => (
          <Motion
            key={preset}
            preset={preset as
              | "fade"
              | "fade-up"
              | "fade-down"
              | "fade-left"
              | "fade-right"
              | "scale"
              | "lift"
              | "slide"
              | "expand"
              | "collapse"}
              speed="slow"
            className="motion-demo-pill"
          >
            {preset}
          </Motion>
        ))}
      </MotionGroup>
    </div>
  </div>
</ShowcaseSection>

<ShowcaseSection
  eyebrow="Reveal"
  title="Scroll-triggered motion"
  description="Elements can reveal themselves when they enter the viewport."
>
  <div className="stack">
    <div className="motion-reveal-spacer" />

    <div className="grid grid--3">
      <Motion preset="fade-up" reveal speed="slow">
        <Card>
          <CardHeader
            eyebrow="Fade up"
            title="Appears on scroll"
          />
          <p>
            This element reveals itself when it enters the viewport.
          </p>
        </Card>
      </Motion>

      <Motion preset="scale" reveal speed="slow">
        <Card>
          <CardHeader
            eyebrow="Scale"
            title="Viewport triggered"
          />
          <p>
            The animation starts only when this card becomes visible.
          </p>
        </Card>
      </Motion>

      <Motion preset="fade-left" reveal speed="slow">
        <Card>
          <CardHeader
            eyebrow="Fade left"
            title="Reusable reveal"
          />
          <p>
            The same primitive can be used on any element.
          </p>
        </Card>
      </Motion>
    </div>
  </div>
</ShowcaseSection>

        <ShowcaseSection
          eyebrow="Cards"
          title="Card composition"
          description="Card itself stays generic; the content inside determines the final use case."
        >
          <div className="grid grid--3">
            {cards.map((card) => (
              <Card key={card.title} variant="outlined">
                <CardHeader {...card} />
              </Card>
            ))}
          </div>
        </ShowcaseSection>

        <ShowcaseSection
          eyebrow="System"
          title="One final checklist"
          description="Every exported UI primitive is represented somewhere in this showcase."
        >
          <Alert variant="success" title="Component coverage">
            The showcase includes every exported UI component, including the
            newer Image, DropdownMenu, and Drawer primitives.
          </Alert>

          <div className="demo-flex">
            <Button
              variant="secondary"
              href="#tokens"
              iconRight={<ArrowUpRight size={15} />}
            >
              Back to tokens
            </Button>
            <Button variant="ghost">
  System ready
</Button>
<Motion preset="fade-up" reveal>
  <div>
    Reveal test
  </div>
</Motion>
          </div>
        </ShowcaseSection>

        <Footer
          brand={<div className="footer__brand">Concept Studio</div>}
          description="Universal UI building blocks for future concept projects."
          columns={footerColumns}
          contact={{
            email: "hello@conceptstudio.com",
            phone: "+1 (415) 555-0148",
            address: "1501 Market Street, San Francisco",
          }}
          socials={[
            { label: "Instagram", href: "/instagram" },
            { label: "X", href: "/x" },
            { label: "LinkedIn", href: "/linkedin" },
            { label: "Dribbble", href: "/dribbble" },
          ]}
          newsletter={{
            title: "Newsletter",
            description: "Useful product notes and launch updates.",
            placeholder: "Email address",
            buttonLabel: "Join",
            onSubmit: (value) => console.log(value),
          }}
          legalLinks={[
            { label: "Privacy", href: "/privacy" },
            { label: "Terms", href: "/terms" },
          ]}
          copyright="© 2026 Concept Studio"
        />
      </ToastProvider>
    </main>
  );
}