import { useId, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { Motion } from "./Motion";
import "./Tabs.css";

export type TabsItem = {
  id: string;
  label: ReactNode;
  content: ReactNode;
  disabled?: boolean;
};

export type TabsProps = {
  items: TabsItem[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  className?: string;
  listClassName?: string;
  tabClassName?: string;
  panelClassName?: string;
};

export function Tabs({
  items,
  value,
  defaultValue,
  onValueChange,
  className = "",
  listClassName = "",
  tabClassName = "",
  panelClassName = "",
}: TabsProps) {
  const fallbackIndex = items.findIndex((item) => !item.disabled);
  const initialValue = defaultValue ?? items[fallbackIndex]?.id ?? items[0]?.id ?? "";
  const [internalValue, setInternalValue] = useState(initialValue);
  const tabsRef = useRef<Array<HTMLButtonElement | null>>([]);
  const generatedId = useId();

  const isControlled = value !== undefined;
  const activeValue = isControlled ? value : internalValue;
  const activeItem = items.find((item) => item.id === activeValue) ?? items[0];

  const setActiveValue = (nextValue: string) => {
    if (isControlled) {
      onValueChange?.(nextValue);
      return;
    }

    setInternalValue(nextValue);
    onValueChange?.(nextValue);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    const enabledItems = items.filter((item) => !item.disabled);
    const currentIndex = enabledItems.findIndex((item) => item.id === activeValue);
    let nextIndex = currentIndex;

    if (event.key === "ArrowRight") {
      event.preventDefault();
      nextIndex = (currentIndex + 1) % enabledItems.length;
    }

    if (event.key === "ArrowLeft") {
      event.preventDefault();
      nextIndex = (currentIndex - 1 + enabledItems.length) % enabledItems.length;
    }

    if (event.key === "Home") {
      event.preventDefault();
      nextIndex = 0;
    }

    if (event.key === "End") {
      event.preventDefault();
      nextIndex = enabledItems.length - 1;
    }

    if (nextIndex === -1 || !enabledItems[nextIndex]) {
      return;
    }

    const nextItem = enabledItems[nextIndex];
    setActiveValue(nextItem.id);

    const nextButton = tabsRef.current.find((button) => button?.dataset.tabId === nextItem.id);
    nextButton?.focus();
  };

  return (
    <div className={["tabs", className].filter(Boolean).join(" ")}>
      <div role="tablist" aria-label="Tabs" className={["tabs__list", listClassName].filter(Boolean).join(" ")}>
        {items.map((item, index) => {
          const isSelected = item.id === activeValue;
          const isDisabled = item.disabled;
          const tabId = `${generatedId}-tab-${item.id}`;
          const panelId = `${generatedId}-panel-${item.id}`;

          return (
            <button
              key={item.id}
              ref={(node) => {
                tabsRef.current[index] = node;
              }}
              type="button"
              role="tab"
              id={tabId}
              aria-selected={isSelected}
              aria-controls={panelId}
              tabIndex={isSelected ? 0 : -1}
              disabled={isDisabled}
              data-tab-id={item.id}
              className={["tabs__tab", isSelected && "tabs__tab--active", tabClassName].filter(Boolean).join(" ")}
              onClick={() => !isDisabled && setActiveValue(item.id)}
              onKeyDown={(event) => handleKeyDown(event, index)}
            >
              {item.label}
            </button>
          );
        })}
      </div>

      {activeItem && (
        <Motion
          as="div"
          preset="fade"
          className={["tabs__panel", panelClassName].filter(Boolean).join(" ")}
          role="tabpanel"
          id={`${generatedId}-panel-${activeItem.id}`}
          aria-labelledby={`${generatedId}-tab-${activeItem.id}`}
        >
          {activeItem.content}
        </Motion>
      )}
    </div>
  );
}
