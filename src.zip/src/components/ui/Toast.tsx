import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { CheckCircle2, Info, TriangleAlert, X, CircleAlert } from "lucide-react";
import { Motion } from "./Motion";
import "./Toast.css";

export type ToastVariant = "info" | "success" | "warning" | "danger";

export type ToastItem = {
  id: string;
  title?: ReactNode;
  message?: ReactNode;
  variant?: ToastVariant;
  duration?: number;
};

type ToastContextValue = {
  addToast: (toast: Omit<ToastItem, "id">) => string;
  removeToast: (id: string) => void;
};

const ToastContext = createContext<ToastContextValue | null>(null);

export function Toast({
  title,
  message,
  variant = "info",
  duration = 4200,
  onClose,
  className = "",
}: Omit<ToastItem, "id"> & { onClose?: () => void; className?: string }) {
  const icons: Record<ToastVariant, ReactNode> = {
    info: <Info size={16} aria-hidden="true" />,
    success: <CheckCircle2 size={16} aria-hidden="true" />,
    warning: <TriangleAlert size={16} aria-hidden="true" />,
    danger: <CircleAlert size={16} aria-hidden="true" />,
  };

  useEffect(() => {
    if (duration <= 0) {
      return;
    }

    const timer = window.setTimeout(() => {
      onClose?.();
    }, duration);

    return () => window.clearTimeout(timer);
  }, [duration, onClose]);

  return (
    <Motion
      preset="fade"
      className={['toast', `toast--${variant}`, className].filter(Boolean).join(' ')}
      role="status"
      aria-live="polite"
      aria-atomic="true"
    >
      <span className="toast__icon" aria-hidden="true">{icons[variant]}</span>
      <div className="toast__body">
        {title && <strong className="toast__title">{title}</strong>}
        {message && <span className="toast__message">{message}</span>}
      </div>
      <button type="button" className="toast__close" aria-label="Close notification" onClick={onClose}>
        <X size={14} aria-hidden="true" />
      </button>
    </Motion>
  );
}

export function ToastViewport({
  toasts,
  onDismiss,
  className = "",
}: {
  toasts: ToastItem[];
  onDismiss: (id: string) => void;
  className?: string;
}) {
  return (
    <div className={['toast-viewport', className].filter(Boolean).join(' ')} aria-live="polite" aria-atomic="false">
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          title={toast.title}
          message={toast.message}
          variant={toast.variant}
          duration={toast.duration}
          onClose={() => onDismiss(toast.id)}
        />
      ))}
    </div>
  );
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const addToast = (toast: Omit<ToastItem, "id">) => {
    const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    setToasts((current) => [...current, { ...toast, id }]);
    return id;
  };

  const removeToast = (id: string) => {
    setToasts((current) => current.filter((toast) => toast.id !== id));
  };

  const value = useMemo<ToastContextValue>(() => ({ addToast, removeToast }), []);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <ToastViewport toasts={toasts} onDismiss={removeToast} />
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);

  if (!context) {
    throw new Error("useToast must be used within a ToastProvider");
  }

  return context;
}
