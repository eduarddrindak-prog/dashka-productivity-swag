import type { ImgHTMLAttributes } from "react";
import "./Avatar.css";

type AvatarSize = "sm" | "md" | "lg";

type AvatarProps = ImgHTMLAttributes<HTMLImageElement> & {
  src?: string;
  alt: string;
  size?: AvatarSize;
  initials?: string;
  variant?: "circle" | "square";
};

export function Avatar({
  src,
  alt,
  size = "md",
  initials,
  variant = "circle",
  className = "",
  ...props
}: AvatarProps) {
  const avatarClassName = [
    "avatar",
    `avatar--${size}`,
    `avatar--${variant}`,
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div className={avatarClassName}>
      {src ? (
        <img src={src} alt={alt} {...props} />
      ) : (
        <div className="avatar__initials">{initials || alt.charAt(0)}</div>
      )}
    </div>
  );
}
