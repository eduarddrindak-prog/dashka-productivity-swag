import {
  cloneElement,
  isValidElement,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type KeyboardEvent as ReactKeyboardEvent,
  type MouseEvent as ReactMouseEvent,
  type ReactElement,
  type ReactNode,
} from "react";
import { Motion } from "./Motion";
import "./Popover.css";

type PopoverPlacement = "top" | "bottom" | "left" | "right";
type PopoverAlign = "start" | "center" | "end";

type PopoverProps = {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  trigger: ReactNode;
  children: ReactNode;
  placement?: PopoverPlacement;
  align?: PopoverAlign;
  disabled?: boolean;
  className?: string;
  contentClassName?: string;
};

type Position = {
  top: number;
  left: number;
};

const GAP = 8;

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

function getPopoverPosition(
  triggerRect: DOMRect,
  contentRect: DOMRect,
  placement: PopoverPlacement,
  align: PopoverAlign,
): Position {
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;

  let nextPlacement = placement;
  let left = 0;
  let top = 0;

  if (placement === "top") {
    top = triggerRect.top - contentRect.height - GAP;
    if (top < 12) {
      nextPlacement = "bottom";
    }
  }

  if (placement === "bottom") {
    top = triggerRect.bottom + GAP;
    if (top + contentRect.height > viewportHeight - 12) {
      nextPlacement = "top";
      top = triggerRect.top - contentRect.height - GAP;
    }
  }

  if (placement === "left") {
    left = triggerRect.left - contentRect.width - GAP;
    if (left < 12) {
      nextPlacement = "right";
    }
  }

  if (placement === "right") {
    left = triggerRect.right + GAP;
    if (left + contentRect.width > viewportWidth - 12) {
      nextPlacement = "left";
      left = triggerRect.left - contentRect.width - GAP;
    }
  }

  if (nextPlacement === "top" || nextPlacement === "bottom") {
    if (align === "start") {
      left = triggerRect.left;
    } else if (align === "center") {
      left = triggerRect.left + triggerRect.width / 2 - contentRect.width / 2;
    } else {
      left = triggerRect.right - contentRect.width;
    }

    if (nextPlacement === "top") {
      top = triggerRect.top - contentRect.height - GAP;
    } else {
      top = triggerRect.bottom + GAP;
    }
  }

  if (nextPlacement === "left" || nextPlacement === "right") {
    if (align === "start") {
      top = triggerRect.top;
    } else if (align === "center") {
      top = triggerRect.top + triggerRect.height / 2 - contentRect.height / 2;
    } else {
      top = triggerRect.bottom - contentRect.height;
    }

    if (nextPlacement === "left") {
      left = triggerRect.left - contentRect.width - GAP;
    } else {
      left = triggerRect.right + GAP;
    }
  }

  left = clamp(left, 12, viewportWidth - contentRect.width - 12);
  top = clamp(top, 12, viewportHeight - contentRect.height - 12);

  return { top, left };
}

export function Popover({
  open,
  onOpenChange,
  trigger,
  children,
  placement = "bottom",
  align = "center",
  disabled = false,
  className = "",
  contentClassName = "",
}: PopoverProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const triggerRef = useRef<HTMLElement | null>(null);
  const contentRef = useRef<HTMLDivElement | null>(null);
  const triggerNodeRef = useRef<HTMLElement | null>(null);
  const contentId = useId().replace(/:/g, "");

  const isControlled = open !== undefined;
  const isOpen = isControlled ? open : internalOpen;

  const setIsOpen = (nextOpen: boolean) => {
    if (!isControlled) {
      setInternalOpen(nextOpen);
    }
    onOpenChange?.(nextOpen);
  };

  useLayoutEffect(() => {
    if (!isOpen || !triggerRef.current || !contentRef.current) {
      return;
    }

    const triggerRect = triggerRef.current.getBoundingClientRect();
    const contentRect = contentRef.current.getBoundingClientRect();
    const nextPosition = getPopoverPosition(triggerRect, contentRect, placement, align);

    contentRef.current.style.left = `${nextPosition.left}px`;
    contentRef.current.style.top = `${nextPosition.top}px`;
  }, [isOpen, placement, align]);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    const handlePointerDown = (event: MouseEvent) => {
      const target = event.target as Node;
      if (!contentRef.current?.contains(target) && !triggerRef.current?.contains(target)) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setIsOpen(false);
      }
    };

    const focusTarget = contentRef.current?.querySelector<HTMLElement>(
      'button:not([disabled]), [href], input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])',
    );

    focusTarget?.focus();

    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) {
      return;
    }

    const handleResize = () => {
      if (!triggerRef.current || !contentRef.current) {
        return;
      }

      const triggerRect = triggerRef.current.getBoundingClientRect();
      const contentRect = contentRef.current.getBoundingClientRect();
      const nextPosition = getPopoverPosition(triggerRect, contentRect, placement, align);
      contentRef.current.style.left = `${nextPosition.left}px`;
      contentRef.current.style.top = `${nextPosition.top}px`;
    };

    window.addEventListener("resize", handleResize);
    window.addEventListener("scroll", handleResize, true);

    return () => {
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("scroll", handleResize, true);
    };
  }, [isOpen, placement, align]);

  const handleTriggerClick = (event: ReactMouseEvent<HTMLElement>) => {
    if (disabled) {
      return;
    }

    if (isValidElement<{
      onClick?: (event: ReactMouseEvent<HTMLElement>) => void;
    }>(trigger)) {
      const triggerProps = trigger.props as {
        onClick?: (event: ReactMouseEvent<HTMLElement>) => void;
      };

      triggerProps.onClick?.(event);
    }

    setIsOpen(!isOpen);
  };

  const handleTriggerKeyDown = (event: ReactKeyboardEvent<HTMLElement>) => {
    if (disabled) {
      return;
    }

    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      setIsOpen(!isOpen);
    }
  };

  const triggerElement = (() => {
    if (isValidElement(trigger)) {
      const triggerProps = trigger.props as {
        onClick?: (event: ReactMouseEvent<HTMLElement>) => void;
        onKeyDown?: (event: ReactKeyboardEvent<HTMLElement>) => void;
        ref?: unknown;
        [key: string]: unknown;
      };

      return cloneElement(trigger as ReactElement<any>, {
        ref: (node: HTMLElement | null) => {
          triggerRef.current = node;
          const existingRef = triggerProps.ref;
          if (typeof existingRef === "function") {
            existingRef(node);
          }
        },
        onClick: handleTriggerClick,
        onKeyDown: (event: ReactKeyboardEvent<HTMLElement>) => {
          triggerProps.onKeyDown?.(event);
          handleTriggerKeyDown(event);
        },
        "aria-expanded": isOpen,
        "aria-haspopup": "dialog",
        "aria-controls": isOpen ? contentId : undefined,
      } as any);
    }

    return (
      <button
        type="button"
        ref={(node) => {
          triggerNodeRef.current = node;
          triggerRef.current = node;
        }}
        className="popover__trigger"
        aria-expanded={isOpen}
        aria-haspopup="dialog"
        aria-controls={isOpen ? contentId : undefined}
        disabled={disabled}
        onClick={() => setIsOpen(!isOpen)}
        onKeyDown={handleTriggerKeyDown}
      >
        {trigger}
      </button>
    );
  })();

  return (
    <div className={['popover', className].filter(Boolean).join(' ')}>
      {triggerElement}

      {isOpen && (
        <Motion
          as="div"
          preset="fade"
          className={['popover__content', contentClassName].filter(Boolean).join(' ')}
          id={contentId}
          role="dialog"
          aria-modal="false"
          ref={contentRef}
          style={
            {
              position: "fixed",
              left: 0,
              top: 0,
              zIndex: 1000,
            } as CSSProperties
          }
        >
          {children}
        </Motion>
      )}
    </div>
  );
}
