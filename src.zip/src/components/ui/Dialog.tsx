import { useEffect, useId, useRef } from "react";
import type { ReactNode } from "react";
import { X } from "lucide-react";
import { Motion } from "./Motion";
import "./Dialog.css";

type DialogSize = "sm" | "md" | "lg" | "xl" | "full";

type DialogProps = {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  closeButton?: boolean;
  size?: DialogSize;
  className?: string;
  contentClassName?: string;
};

export function Dialog({
  open,
  onClose,
  title,
  description,
  children,
  closeButton = true,
  size = "md",
  className = "",
  contentClassName = "",
}: DialogProps) {
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const lastFocusedRef = useRef<HTMLElement | null>(null);
  const titleId = useId().replace(/:/g, "");
  const descriptionId = useId().replace(/:/g, "");

  useEffect(() => {
    if (!open) {
      return;
    }

    lastFocusedRef.current = document.activeElement as HTMLElement | null;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const focusTarget =
      closeRef.current ??
      dialogRef.current?.querySelector<HTMLElement>(
        'button:not([disabled]), [href], input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])',
      );

    const focusTimer = window.setTimeout(() => {
      focusTarget?.focus();
    }, 0);

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
        return;
      }

      if (event.key !== "Tab" || !dialogRef.current) {
        return;
      }

      const focusableElements = dialogRef.current.querySelectorAll<HTMLElement>(
        'button:not([disabled]), [href], input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])',
      );

      if (!focusableElements.length) {
        return;
      }

      const first = focusableElements[0];
      const last = focusableElements[focusableElements.length - 1];

      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", handleKeyDown);

    return () => {
      window.clearTimeout(focusTimer);
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKeyDown);
      lastFocusedRef.current?.focus();
    };
  }, [open, onClose]);

  if (!open) {
    return null;
  }

  const hasTitle = Boolean(title);
  const hasDescription = Boolean(description);

  return (
    <Motion
      preset="fade"
      className={['dialog-root', className].filter(Boolean).join(' ')}
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      }}
      aria-hidden={!open}
    >
      <Motion
        preset="scale"
        speed="base"
        className={['dialog', `dialog--${size}`].filter(Boolean).join(' ')}
        role="dialog"
        aria-modal="true"
        aria-labelledby={hasTitle ? titleId : undefined}
        aria-describedby={hasDescription ? descriptionId : undefined}
        ref={dialogRef as any}
        tabIndex={-1}
        onClick={(event) => event.stopPropagation()}
      >
        {(hasTitle || closeButton) && (
          <div className="dialog__header">
            {hasTitle && (
              <div className="dialog__heading">
                <h2 id={titleId} className="dialog__title">
                  {title}
                </h2>
                {hasDescription && (
                  <p id={descriptionId} className="dialog__description">
                    {description}
                  </p>
                )}
              </div>
            )}

            {closeButton && (
              <button
                ref={closeRef}
                type="button"
                className="dialog__close"
                onClick={onClose}
                aria-label="Close dialog"
              >
                <X size={16} aria-hidden="true" />
              </button>
            )}
          </div>
        )}

        <div className={['dialog__content', contentClassName].filter(Boolean).join(' ')}>
          {children}
        </div>
      </Motion>
    </Motion>
  );
}
