import type { InputHTMLAttributes } from "react";
import { useRef, useState } from "react";
import { Search as SearchIcon, X, Loader } from "lucide-react";
import "./Search.css";

type SearchProps = Omit<InputHTMLAttributes<HTMLInputElement>, "type"> & {
  onClear?: () => void;
  loading?: boolean;
  clearable?: boolean;
  iconClassName?: string;
  wrapperClassName?: string;
};

export function Search({
  value,
  onChange,
  onClear,
  loading = false,
  clearable = true,
  placeholder = "Search...",
  disabled = false,
  className = "",
  iconClassName = "",
  wrapperClassName = "",
  ...props
}: SearchProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const hasValue = !!value && value.toString().length > 0;

  const handleClear = () => {
  onClear?.();
  inputRef.current?.focus();
};

  return (
    <div className={`search ${wrapperClassName}`.trim()}>
      <div className="search__inner">
        <SearchIcon
          className={`search__icon search__icon--start ${iconClassName}`.trim()}
          size={18}
          aria-hidden
        />
        <input
          ref={inputRef}
          type="search"
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled || loading}
          className={`search__input ${className}`.trim()}
          aria-label="Search"
          {...props}
        />
        {loading && (
          <Loader
            className={`search__icon search__icon--end search__icon--loading ${iconClassName}`.trim()}
            size={18}
            aria-hidden
          />
        )}
        {!loading && clearable && hasValue && (
          <button
            type="button"
            className="search__clear"
            onClick={handleClear}
            aria-label="Clear search"
            tabIndex={-1}
          >
            <X
              className={`search__icon search__icon--end ${iconClassName}`.trim()}
              size={18}
              aria-hidden
            />
          </button>
        )}
      </div>
    </div>
  );
}
