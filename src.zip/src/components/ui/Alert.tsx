import type { HTMLAttributes, ReactNode } from "react";
import { AlertCircle, CheckCircle2, Info, TriangleAlert, X } from "lucide-react";
import "./Alert.css";

export type AlertVariant = "info" | "success" | "warning" | "danger";

export type AlertProps = HTMLAttributes<HTMLDivElement> & {
  variant?: AlertVariant;
  title?: ReactNode;
  children?: ReactNode;
  icon?: ReactNode;
  closeButton?: boolean;
  onClose?: () => void;
  className?: string;
};

const variantConfig: Record<AlertVariant, { icon: ReactNode; label: string }> = {
  info: { icon: <Info size={16} aria-hidden="true" />, label: "Information" },
  success: { icon: <CheckCircle2 size={16} aria-hidden="true" />, label: "Success" },
  warning: { icon: <TriangleAlert size={16} aria-hidden="true" />, label: "Warning" },
  danger: { icon: <AlertCircle size={16} aria-hidden="true" />, label: "Danger" },
};

export function Alert({
  variant = "info",
  title,
  children,
  icon,
  closeButton = false,
  onClose,
  className = "",
  ...props
}: AlertProps) {
  const resolvedIcon = icon ?? variantConfig[variant].icon;

  return (
    <div
      className={["alert", `alert--${variant}`, className].filter(Boolean).join(" ")}
      role="alert"
      {...props}
    >
      <div className="alert__content">
        <span className="alert__icon" aria-hidden="true">
          {resolvedIcon}
        </span>
        <div className="alert__body">
          {title && <div className="alert__title">{title}</div>}
          {children && <div className="alert__message">{children}</div>}
        </div>
      </div>

      {closeButton && (
        <button type="button" className="alert__close" onClick={onClose} aria-label="Close alert">
          <X size={14} aria-hidden="true" />
        </button>
      )}
    </div>
  );
}
