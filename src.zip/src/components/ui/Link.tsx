import type { AnchorHTMLAttributes, ReactNode } from "react";
import { ArrowUpRight } from "lucide-react";
import "./Link.css";

type LinkVariant = "default" | "accent" | "muted";
type LinkSize = "sm" | "md" | "lg";

type LinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & {
  children: ReactNode;
  variant?: LinkVariant;
  size?: LinkSize;
  withArrow?: boolean;
  underline?: boolean;
  external?: boolean;
};

export function Link({
  children,
  variant = "default",
  size = "md",
  withArrow = false,
  underline = false,
  external = false,
  className = "",
  href,
  ...props
}: LinkProps) {
  const linkClassName = [
    "link",
    `link--${variant}`,
    `link--${size}`,
    underline && "link--underline",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <a
      href={href}
      className={`${linkClassName} ${className}`.trim()}
      target={external ? "_blank" : undefined}
      rel={external ? "noopener noreferrer" : undefined}
      {...props}
    >
      {children}
      {withArrow && (
        <ArrowUpRight className="link__arrow" />
      )}
    </a>
  );
}
