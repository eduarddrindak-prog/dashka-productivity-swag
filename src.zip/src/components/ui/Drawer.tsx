import {
  useEffect,
  useRef,
  type ReactNode,
} from "react";

import "./Drawer.css";

export type DrawerSide =
  | "left"
  | "right"
  | "top"
  | "bottom";

export type DrawerSize =
  | "sm"
  | "md"
  | "lg"
  | "full";

export type DrawerProps = {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  side?: DrawerSide;
  size?: DrawerSize;
  title?: string;
  description?: string;
  closeButton?: boolean;
  className?: string;
  contentClassName?: string;
  closeOnOverlayClick?: boolean;
  closeOnEscape?: boolean;
};

export function Drawer({
  open,
  onClose,
  children,
  side = "right",
  size = "md",
  title,
  description,
  closeButton = true,
  className = "",
  contentClassName = "",
  closeOnOverlayClick = true,
  closeOnEscape = true,
}: DrawerProps) {
  const drawerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;

    const previousOverflow =
      document.body.style.overflow;

    document.body.style.overflow = "hidden";

    const handleKeyDown = (
      event: KeyboardEvent
    ) => {
      if (
        closeOnEscape &&
        event.key === "Escape"
      ) {
        event.preventDefault();
        onClose();
      }

      if (event.key !== "Tab") return;

      const drawer = drawerRef.current;

      if (!drawer) return;

      const focusable = drawer.querySelectorAll<HTMLElement>(
        'button:not([disabled]), a[href], input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );

      if (!focusable.length) {
        event.preventDefault();
        return;
      }

      const first = focusable[0];
      const last =
        focusable[focusable.length - 1];

      if (
        event.shiftKey &&
        document.activeElement === first
      ) {
        event.preventDefault();
        last.focus();
      } else if (
        !event.shiftKey &&
        document.activeElement === last
      ) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener(
      "keydown",
      handleKeyDown
    );

    requestAnimationFrame(() => {
      const firstFocusable =
        drawerRef.current?.querySelector<HTMLElement>(
          'button:not([disabled]), a[href], input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );

      firstFocusable?.focus();
    });

    return () => {
      document.body.style.overflow =
        previousOverflow;

      document.removeEventListener(
        "keydown",
        handleKeyDown
      );
    };
  }, [
    open,
    onClose,
    closeOnEscape,
  ]);

  if (!open) return null;

  const titleId = title
    ? "drawer-title"
    : undefined;

  const descriptionId = description
    ? "drawer-description"
    : undefined;

  return (
    <div
      className={`drawer drawer--${side} ${className}`.trim()}
    >
      <div
        className="drawer__overlay"
        aria-hidden="true"
        onClick={() => {
          if (closeOnOverlayClick) {
            onClose();
          }
        }}
      />

      <div
        ref={drawerRef}
        className={`drawer__panel drawer__panel--${size} ${contentClassName}`.trim()}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descriptionId}
      >
        <div className="drawer__header">
          <div className="drawer__heading">
            {title && (
              <h2
                id={titleId}
                className="drawer__title"
              >
                {title}
              </h2>
            )}

            {description && (
              <p
                id={descriptionId}
                className="drawer__description"
              >
                {description}
              </p>
            )}
          </div>

          {closeButton && (
            <button
              type="button"
              className="drawer__close"
              aria-label="Close"
              onClick={onClose}
            >
              <span aria-hidden="true">
                ×
              </span>
            </button>
          )}
        </div>

        <div className="drawer__body">
          {children}
        </div>
      </div>
    </div>
  );
}