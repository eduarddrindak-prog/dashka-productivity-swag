import type { ReactNode } from "react";
import { useEffect, useId, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import { Motion } from "./Motion";
import "./Select.css";

export type SelectOption = {
  value: string;
  label: ReactNode;
  disabled?: boolean;
};

type SelectProps = {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  invalid?: boolean;
  name?: string;
  className?: string;
  triggerClassName?: string;
  contentClassName?: string;
};

const GAP = 8;

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

export function Select({
  value,
  defaultValue,
  onValueChange,
  options,
  placeholder = "Select an option",
  disabled = false,
  required = false,
  invalid = false,
  name,
  className = "",
  triggerClassName = "",
  contentClassName = "",
}: SelectProps) {
  const [open, setOpen] = useState(false);
  const [internalValue, setInternalValue] = useState(defaultValue || "");
  const triggerRef = useRef<HTMLButtonElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const highlightedRef = useRef<string | null>(null);
  const contentId = useId().replace(/:/g, "");

  const isControlled = value !== undefined;
  const displayValue = isControlled ? value : internalValue;

  const selectedOption = options.find((opt) => opt.value === displayValue);
  const displayLabel = selectedOption?.label || placeholder;

  const handleValueChange = (newValue: string) => {
  if (!isControlled) {
    setInternalValue(newValue);
  }

 onValueChange?.(newValue);
highlightedRef.current = newValue;
setOpen(false);
  triggerRef.current?.focus();
};

  // Position the content menu
  useEffect(() => {
    if (!open || !triggerRef.current || !contentRef.current) {
      return;
    }

    const triggerRect = triggerRef.current.getBoundingClientRect();
    const contentRect = contentRef.current.getBoundingClientRect();
    const viewportHeight = window.innerHeight;

    let top = triggerRect.bottom + GAP;

    if (top + contentRect.height > viewportHeight - 12) {
      top = triggerRect.top - contentRect.height - GAP;
    }

    const left = triggerRect.left;

    contentRef.current.style.top = `${top}px`;
    contentRef.current.style.left = `${left}px`;
    contentRef.current.style.width = `${triggerRect.width}px`;
  }, [open]);

  // Handle outside click and keyboard
  useEffect(() => {
    if (!open) {
      return;
    }

    const handlePointerDown = (event: MouseEvent) => {
      const target = event.target as Node;
      if (!contentRef.current?.contains(target) && !triggerRef.current?.contains(target)) {
        setOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setOpen(false);
        triggerRef.current?.focus();
      } else if (event.key === "ArrowDown") {
        event.preventDefault();
        highlightedRef.current = null;
        const currentIndex = options.findIndex((opt) => opt.value === displayValue);
        let nextIndex = currentIndex + 1;
        while (nextIndex < options.length && options[nextIndex].disabled) {
          nextIndex++;
        }
        if (nextIndex < options.length) {
          highlightedRef.current = options[nextIndex].value;
          const item = listRef.current?.querySelector(`[data-value="${options[nextIndex].value}"]`) as HTMLElement;
          item?.scrollIntoView({ block: "nearest" });
        }
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        highlightedRef.current = null;
        const currentIndex = options.findIndex((opt) => opt.value === displayValue);
        let nextIndex = currentIndex - 1;
        while (nextIndex >= 0 && options[nextIndex].disabled) {
          nextIndex--;
        }
        if (nextIndex >= 0) {
          highlightedRef.current = options[nextIndex].value;
          const item = listRef.current?.querySelector(`[data-value="${options[nextIndex].value}"]`) as HTMLElement;
          item?.scrollIntoView({ block: "nearest" });
        }
      } else if (event.key === "Home") {
        event.preventDefault();
        highlightedRef.current = null;
        let nextIndex = 0;
        while (nextIndex < options.length && options[nextIndex].disabled) {
          nextIndex++;
        }
        if (nextIndex < options.length) {
          highlightedRef.current = options[nextIndex].value;
          const item = listRef.current?.querySelector(`[data-value="${options[nextIndex].value}"]`) as HTMLElement;
          item?.scrollIntoView({ block: "nearest" });
        }
      } else if (event.key === "End") {
        event.preventDefault();
        highlightedRef.current = null;
        let nextIndex = options.length - 1;
        while (nextIndex >= 0 && options[nextIndex].disabled) {
          nextIndex--;
        }
        if (nextIndex >= 0) {
          highlightedRef.current = options[nextIndex].value;
          const item = listRef.current?.querySelector(`[data-value="${options[nextIndex].value}"]`) as HTMLElement;
          item?.scrollIntoView({ block: "nearest" });
        }
      } else if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        if (highlightedRef.current) {
          const option = options.find((opt) => opt.value === highlightedRef.current);
          if (option && !option.disabled) {
            handleValueChange(option.value);
          }
        }
      }
    };

    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [open, displayValue, options]);

  return (
    <div className={`select ${className}`.trim()}>
      <button
        ref={triggerRef}
        className={`select__trigger ${triggerClassName}`.trim()}
        onClick={() => !disabled && setOpen(!open)}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            if (!disabled) {
              setOpen(!open);
            }
          }
        }}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={open ? contentId : undefined}
        aria-invalid={invalid}
        aria-required={required}
        disabled={disabled}
        type="button"
      >
        <span className="select__label">
          {displayLabel}
        </span>
        <ChevronDown
          className="select__icon"
          size={18}
          aria-hidden
        />
      </button>

      {open && (
        <Motion
          as="div"
          preset="fade"
          className={`select__content ${contentClassName}`.trim()}
          id={contentId}
          role="listbox"
          aria-label="Options"
          ref={contentRef}
        >
          <ul
            ref={listRef}
            className="select__list"
            role="presentation"
          >
            {options.map((option) => (
              <li key={option.value} role="presentation">
                <button
                  type="button"
                  className="select__option"
                  data-value={option.value}
                  onClick={() => !option.disabled && handleValueChange(option.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      if (!option.disabled) {
                        handleValueChange(option.value);
                      }
                    }
                  }}
                  role="option"
                  aria-selected={option.value === displayValue}
                  disabled={option.disabled}
                >
                  {option.label}
                </button>
              </li>
            ))}
          </ul>
        </Motion>
      )}

      {name && (
        <input
          type="hidden"
          name={name}
          value={displayValue}
        />
      )}
    </div>
  );
}
