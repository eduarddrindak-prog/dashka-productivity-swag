import type { HTMLAttributes } from "react";
import "./Spinner.css";

export type SpinnerSize = "sm" | "md" | "lg";

export type SpinnerProps = HTMLAttributes<HTMLSpanElement> & {
  size?: SpinnerSize;
  label?: string;
};

export function Spinner({ size = "md", label = "Loading", className = "", ...props }: SpinnerProps) {
  return (
    <span
      className={["spinner", `spinner--${size}`, className].filter(Boolean).join(" ")}
      role="status"
      aria-live="polite"
      aria-label={label}
      {...props}
    >
      <span className="spinner__ring" aria-hidden="true" />
    </span>
  );
}
