import "./Price.css";

type PriceProps = {
  amount: number | string;
  currency?: string;
  period?: string;
  size?: "sm" | "md" | "lg";
};

export function Price({ amount, currency = "$", period, size = "md" }: PriceProps) {
  return (
    <div className={`price price--${size}`}>
      <span className="price__currency">{currency}</span>
      <span className="price__amount">{amount}</span>
      {period && <span className="price__period">/{period}</span>}
    </div>
  );
}
