import "./Divider.css";

type DividerProps = {
  orientation?: "horizontal" | "vertical";
  variant?: "default" | "subtle";
  spacing?: "sm" | "md" | "lg";
};

export function Divider({ orientation = "horizontal", variant = "default", spacing = "md" }: DividerProps) {
  return <hr className={`divider divider--${orientation} divider--${variant} divider--${spacing}`} />;
}
