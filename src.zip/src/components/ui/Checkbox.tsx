import type { InputHTMLAttributes } from "react";
import { Check } from "lucide-react";
import "./Checkbox.css";

type CheckboxSize = "sm" | "md" | "lg";

type CheckboxProps = Omit<InputHTMLAttributes<HTMLInputElement>, "size"> & {
  label?: string;
  size?: CheckboxSize;
};

export function Checkbox({ label, size = "md", className = "", ...props }: CheckboxProps) {
  return (
    <label className={`checkbox checkbox--${size} ${className}`.trim()}>
      <input type="checkbox" className="checkbox__input" {...props} />
      <div className="checkbox__box">
        <Check className="checkbox__icon" />
      </div>
      {label && <span className="checkbox__label">{label}</span>}
    </label>
  );
}
