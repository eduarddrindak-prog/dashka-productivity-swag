import type { HTMLAttributes } from "react";
import "./Progress.css";

export type ProgressProps = HTMLAttributes<HTMLDivElement> & {
  value: number;
  max?: number;
  size?: "sm" | "md" | "lg";
  label?: string;
};

export function Progress({
  value,
  max = 100,
  size = "md",
  label,
  className = "",
  ...props
}: ProgressProps) {
  const clampedValue = Math.min(Math.max(value, 0), max);
  const percentage = (clampedValue / max) * 100;

  return (
    <div
      className={["progress", `progress--${size}`, className].filter(Boolean).join(" ")}
      role="progressbar"
      aria-valuenow={clampedValue}
      aria-valuemin={0}
      aria-valuemax={max}
      aria-label={label}
      {...props}
    >
      <div className="progress__track">
        <div className="progress__fill" style={{ width: `${percentage}%` }} />
      </div>
    </div>
  );
}
