import type { InputHTMLAttributes } from "react";
import "./Radio.css";

type RadioSize = "sm" | "md" | "lg";

type RadioProps = Omit<InputHTMLAttributes<HTMLInputElement>, "size"> & {
  label?: string;
  size?: RadioSize;
};

export function Radio({ label, size = "md", className = "", ...props }: RadioProps) {
  return (
    <label className={`radio radio--${size} ${className}`.trim()}>
      <input type="radio" className="radio__input" {...props} />
      <div className="radio__circle">
        <div className="radio__dot" />
      </div>
      {label && <span className="radio__label">{label}</span>}
    </label>
  );
}
