import type { ButtonHTMLAttributes, ReactNode } from "react";
import "./IconButton.css";

export type IconButtonVariant = "primary" | "secondary" | "ghost" | "danger";
export type IconButtonSize = "sm" | "md" | "lg";

export type IconButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: IconButtonVariant;
  size?: IconButtonSize;
  icon: ReactNode;
  label: string;
};

export function IconButton({
  variant = "primary",
  size = "md",
  icon,
  label,
  className = "",
  ...props
}: IconButtonProps) {
  return (
    <button
      type="button"
      className={["icon-button", `icon-button--${variant}`, `icon-button--${size}`, className].filter(Boolean).join(" ")}
      aria-label={label}
      title={label}
      {...props}
    >
      {icon}
    </button>
  );
}
