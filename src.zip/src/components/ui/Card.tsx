import type { HTMLAttributes, ReactNode } from "react";
import "./Card.css";

type CardVariant = "default" | "outlined" | "subtle" | "elevated";

type CardProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  variant?: CardVariant;
  interactive?: boolean;
};

type CardHeaderProps = {
  eyebrow?: string;
  title: string;
  description?: string;
};

export function Card({
  className = "",
  variant = "default",
  interactive = true,
  children,
  ...props
}: CardProps) {
  return (
    <div
      className={["card", `card--${variant}`, !interactive && "card--static", className]
        .filter(Boolean)
        .join(" ")}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardHeader({ eyebrow, title, description }: CardHeaderProps) {
  return (
    <div className="card-header">
      {eyebrow && <p className="card-eyebrow">{eyebrow}</p>}
      <h3 className="card-title">{title}</h3>
      {description && <p className="card-description">{description}</p>}
    </div>
  );
}
