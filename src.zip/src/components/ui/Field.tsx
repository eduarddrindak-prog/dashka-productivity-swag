import type {
  InputHTMLAttributes,
  ReactElement,
  ReactNode,
  TextareaHTMLAttributes,
} from "react";
import { useId } from "react";
import "./Field.css";
import React from "react";

type FieldProps = {
  label: string;
  hint?: string;
  error?: string;
  success?: string;
  required?: boolean;
  disabled?: boolean;
  children: ReactNode;
  className?: string;
};

export function Field({
  label,
  hint,
  error,
  success,
  required,
  disabled,
  children,
  className = "",
}: FieldProps) {
  const controlId = useId().replace(/:/g, "");
  const hintId = `${controlId}-hint`;
  const errorId = `${controlId}-error`;

  const ariaDescribedBy = [
    hint && hintId,
    error && errorId,
  ]
    .filter(Boolean)
    .join(" ");

  const child = children as ReactElement<
    InputHTMLAttributes<HTMLInputElement> &
      TextareaHTMLAttributes<HTMLTextAreaElement> & {
        id?: string;
        "aria-describedby"?: string;
        "aria-invalid"?: boolean;
        disabled?: boolean;
        required?: boolean;
      }
  >;

  const control = React.isValidElement(child)
    ? React.cloneElement(child, {
        id: child.props.id ?? controlId,
        "aria-describedby": [
          child.props["aria-describedby"],
          ariaDescribedBy,
        ]
          .filter(Boolean)
          .join(" ") || undefined,
        "aria-invalid": error
          ? true
          : child.props["aria-invalid"],
        disabled:
          child.props.disabled ?? disabled,
        required:
          child.props.required ?? required,
      })
    : children;

  return (
    <div
      className={`field ${className}`.trim()}
      data-disabled={disabled}
      data-error={!!error}
      data-success={!!success && !error}
    >
      <div className="field__header">
        <label
          className="field__label"
          htmlFor={controlId}
        >
          {label}

          {required && (
            <span
              className="field__required"
              aria-label="required"
            >
              *
            </span>
          )}
        </label>
      </div>

      <div className="field__control">
        {control}
      </div>

      {(hint || error || success) && (
        <div className="field__footer">
          {error && (
            <span
              className="field__error"
              id={errorId}
              role="alert"
            >
              {error}
            </span>
          )}

          {!error && success && (
            <span
              className="field__success"
              id={errorId}
            >
              {success}
            </span>
          )}

          {hint && !error && (
            <span
              className="field__hint"
              id={hintId}
            >
              {hint}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

export function Input(
  props: InputHTMLAttributes<HTMLInputElement>
) {
  return (
    <input
      {...props}
      className={`field-control ${props.className ?? ""}`.trim()}
    />
  );
}

export function Textarea(
  props: TextareaHTMLAttributes<HTMLTextAreaElement>
) {
  return (
    <textarea
      {...props}
      className={`field-control field-control--textarea ${props.className ?? ""}`.trim()}
    />
  );
}