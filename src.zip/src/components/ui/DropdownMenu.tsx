import {
  cloneElement,
  isValidElement,
  useEffect,
  useId,
  useRef,
  useState,
  type KeyboardEvent,
  type ReactElement,
  type ReactNode,
} from "react";

import "./DropdownMenu.css";

export type DropdownMenuItem = {
  id: string;
  label: ReactNode;
  onSelect?: () => void;
  disabled?: boolean;
  destructive?: boolean;
  separatorBefore?: boolean;
};

export type DropdownMenuProps = {
  trigger: ReactElement;
  items: DropdownMenuItem[];
  open?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  align?: "start" | "center" | "end";
  className?: string;
  menuClassName?: string;
  ariaLabel?: string;
};

export function DropdownMenu({
  trigger,
  items,
  open: controlledOpen,
  defaultOpen = false,
  onOpenChange,
  align = "start",
  className = "",
  menuClassName = "",
  ariaLabel = "Menu",
}: DropdownMenuProps) {
  const menuId = `dropdown-menu-${useId().replace(/:/g, "")}`;

  const [internalOpen, setInternalOpen] =
    useState(defaultOpen);

  const open =
    controlledOpen !== undefined
      ? controlledOpen
      : internalOpen;

  const [highlightedIndex, setHighlightedIndex] =
    useState<number | null>(null);

  const rootRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const triggerRef =
    useRef<HTMLElement | null>(null);

  const setOpen = (nextOpen: boolean) => {
    if (controlledOpen === undefined) {
      setInternalOpen(nextOpen);
    }

    onOpenChange?.(nextOpen);

    if (!nextOpen) {
      setHighlightedIndex(null);
    }
  };

  const enabledIndexes = items
    .map((item, index) =>
      item.disabled ? null : index
    )
    .filter(
      (index): index is number =>
        index !== null
    );

  const focusItem = (index: number) => {
    const element =
      menuRef.current?.querySelector(
        `[data-dropdown-item-index="${index}"]`
      ) as HTMLElement | null;

    element?.focus();
    setHighlightedIndex(index);
  };

  const openMenu = (initialIndex?: number) => {
    setOpen(true);

    requestAnimationFrame(() => {
      const firstIndex =
        initialIndex ??
        enabledIndexes[0];

      if (firstIndex !== undefined) {
        focusItem(firstIndex);
      }
    });
  };

  const closeMenu = () => {
    setOpen(false);

    requestAnimationFrame(() => {
      triggerRef.current?.focus();
    });
  };

  useEffect(() => {
    if (!open) {
      return;
    }

    const handlePointerDown = (
      event: PointerEvent
    ) => {
      if (
        rootRef.current &&
        !rootRef.current.contains(
          event.target as Node
        )
      ) {
        closeMenu();
      }
    };

    const handleKeyDown = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        closeMenu();
      }
    };

    document.addEventListener(
      "pointerdown",
      handlePointerDown
    );

    document.addEventListener(
      "keydown",
      handleKeyDown
    );

    return () => {
      document.removeEventListener(
        "pointerdown",
        handlePointerDown
      );

      document.removeEventListener(
        "keydown",
        handleKeyDown
      );
    };
  }, [open]);

  const handleTriggerKeyDown = (
    event: KeyboardEvent
  ) => {
    if (
      event.key === "Enter" ||
      event.key === " " ||
      event.key === "ArrowDown"
    ) {
      event.preventDefault();

      if (open) {
        focusItem(
          highlightedIndex ??
            enabledIndexes[0]
        );
      } else {
        openMenu();
      }

      return;
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();

      if (!open) {
        openMenu(
          enabledIndexes[
            enabledIndexes.length - 1
          ]
        );
      }

      return;
    }
  };

  const handleMenuKeyDown = (
    event: KeyboardEvent
  ) => {
    if (
      event.key === "Escape"
    ) {
      event.preventDefault();
      closeMenu();
      return;
    }

    if (
      event.key === "ArrowDown" ||
      event.key === "ArrowUp"
    ) {
      event.preventDefault();

      if (!enabledIndexes.length) {
        return;
      }

      const currentPosition =
        highlightedIndex === null
          ? -1
          : enabledIndexes.indexOf(
              highlightedIndex
            );

      const direction =
        event.key === "ArrowDown"
          ? 1
          : -1;

      const nextPosition =
        currentPosition === -1
          ? direction === 1
            ? 0
            : enabledIndexes.length - 1
          : (
              currentPosition +
              direction +
              enabledIndexes.length
            ) %
            enabledIndexes.length;

      focusItem(
        enabledIndexes[nextPosition]
      );

      return;
    }

    if (event.key === "Home") {
      event.preventDefault();

      if (enabledIndexes[0] !== undefined) {
        focusItem(enabledIndexes[0]);
      }

      return;
    }

    if (event.key === "End") {
      event.preventDefault();

      const last =
        enabledIndexes[
          enabledIndexes.length - 1
        ];

      if (last !== undefined) {
        focusItem(last);
      }
    }
  };

  const handleItemSelect = (
    item: DropdownMenuItem
  ) => {
    if (item.disabled) {
      return;
    }

    item.onSelect?.();
    closeMenu();
  };

  const triggerElement = (() => {
  if (!isValidElement(trigger)) {
    return trigger;
  }

  type TriggerProps = {
    ref?: React.Ref<HTMLElement>;
    id?: string;
    "aria-haspopup"?: string;
    "aria-expanded"?: boolean;
    "aria-controls"?: string;
    onClick?: (
      event: React.MouseEvent
    ) => void;
    onKeyDown?: (
      event: React.KeyboardEvent
    ) => void;
  };

  const typedTrigger =
    trigger as ReactElement<TriggerProps>;

  return cloneElement(typedTrigger, {
    ref: (node: HTMLElement | null) => {
      triggerRef.current = node;
    },

    "aria-haspopup": "menu",
    "aria-expanded": open,
    "aria-controls": open
      ? menuId
      : undefined,

    onClick: (event) => {
      typedTrigger.props.onClick?.(event);

      if (!event.defaultPrevented) {
        if (open) {
          closeMenu();
        } else {
          openMenu();
        }
      }
    },

    onKeyDown: (event) => {
      typedTrigger.props.onKeyDown?.(event);

      if (!event.defaultPrevented) {
        handleTriggerKeyDown(event);
      }
    },
  });
})();

  return (
    <div
      ref={rootRef}
      className={`dropdown-menu ${className}`.trim()}
    >
      {triggerElement}

      {open && (
        <div
          ref={menuRef}
          id={menuId}
          className={`dropdown-menu__content dropdown-menu__content--${align} ${menuClassName}`.trim()}
          role="menu"
          aria-label={ariaLabel}
          onKeyDown={handleMenuKeyDown}
        >
          {items.map((item, index) => (
            <div key={item.id}>
              {item.separatorBefore && (
                <div
                  className="dropdown-menu__separator"
                  role="separator"
                />
              )}

              <button
                type="button"
                className={[
                  "dropdown-menu__item",
                  item.destructive &&
                    "dropdown-menu__item--destructive",
                ]
                  .filter(Boolean)
                  .join(" ")}
                data-dropdown-item-index={
                  index
                }
                role="menuitem"
                disabled={item.disabled}
                tabIndex={
                  highlightedIndex === index
                    ? 0
                    : -1
                }
                onFocus={() =>
                  setHighlightedIndex(index)
                }
                onClick={() =>
                  handleItemSelect(item)
                }
              >
                {item.label}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}