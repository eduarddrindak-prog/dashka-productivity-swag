import { useRef, useState, type ReactNode } from "react";
import "./Tooltip.css";

export type TooltipSide = "top" | "right" | "bottom" | "left";
export type TooltipAlign = "start" | "center" | "end";

export type TooltipProps = {
  content: ReactNode;
  children: ReactNode;
  side?: TooltipSide;
  align?: TooltipAlign;
  delay?: number;
  className?: string;
  disabled?: boolean;
};

export function Tooltip({
  content,
  children,
  side = "top",
  align = "center",
  delay = 120,
  className = "",
  disabled = false,
}: TooltipProps) {
  const [open, setOpen] = useState(false);
  const timeoutRef = useRef<number | null>(null);

  const clearTimer = () => {
    if (timeoutRef.current !== null) {
      window.clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  };

  const scheduleOpen = () => {
    if (disabled) return;
    clearTimer();
    timeoutRef.current = window.setTimeout(() => setOpen(true), delay);
  };

  const close = () => {
    clearTimer();
    setOpen(false);
  };

  return (
    <span
      className={["tooltip", className].filter(Boolean).join(" ")}
      onMouseEnter={scheduleOpen}
      onMouseLeave={close}
      onFocus={scheduleOpen}
      onBlur={close}
    >
      <span className="tooltip__trigger">{children}</span>
      {!disabled && open && (
        <span
          role="tooltip"
          className={["tooltip__content", `tooltip__content--${side}`, `tooltip__content--${align}`].filter(Boolean).join(" ")}
          aria-hidden={!open}
        >
          {content}
        </span>
      )}
    </span>
  );
}
