import type { InputHTMLAttributes } from "react";
import "./Toggle.css";

type ToggleSize = "sm" | "md" | "lg";

type ToggleProps = Omit<InputHTMLAttributes<HTMLInputElement>, "size"> & {
  label?: string;
  size?: ToggleSize;
};

export function Toggle({ label, size = "md", className = "", ...props }: ToggleProps) {
  return (
    <label className={`toggle toggle--${size} ${className}`.trim()}>
      <input type="checkbox" className="toggle__input" {...props} />
      <div className="toggle__switch">
        <div className="toggle__thumb" />
      </div>
      {label && <span className="toggle__label">{label}</span>}
    </label>
  );
}
